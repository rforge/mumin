### Encoding: utf-8

### Name: QAIC
### Title: Quasi AIC
### Aliases: QAIC
### Keywords: models

### ** Examples

budworm <- data.frame(ldose = rep(0:5, 2), numdead = c(1, 4, 9, 13, 18, 20, 0, 2, 6, 10, 12, 16), sex = factor(rep(c("M", "F"), c(6, 6))))
budworm$SF <- cbind(budworm$numdead, 20 - budworm$numdead)
budworm.qlg <- glm(SF ~ sex*ldose, family = quasibinomial, data = budworm)

dd1 <- dredge(budworm.qlg, rank = "QAIC", chat = summary(budworm.qlg)$dispersion)
gm1 <- get.models(dd1, 1:4)

model.avg(gm1)

model.avg(gm1[[1]], gm1[[2]], rank = "QAIC", rank.args = list(chat = 1))





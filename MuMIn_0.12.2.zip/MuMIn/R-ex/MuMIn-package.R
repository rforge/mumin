### Encoding: utf-8

### Name: MuMIn-package
### Title: Multi model inference
### Aliases: MuMIn-package MuMIn
### Keywords: package models

### ** Examples


fm1 <- lm(Fertility ~ . , data = swiss)

dd <- dredge(fm1)
dd
#list of models with delta.aicc < 4
top.models.1 <- get.models(dd, subset = delta < 4)
model.avg(top.models.1) # get averaged coefficients

#or as a 95% confidence set:
top.models.2 <- get.models(dd, cumsum(weight) <= .95)

model.avg(top.models.2) # get averaged coefficients

# Mixed models:

data(Orthodont, package="nlme")

require(nlme)
fm2 <- lme(distance ~ age + Sex, data = Orthodont, random = ~ 1 | Subject, method="ML")
dredge(fm2)

require(lme4)
fm3 <- lmer(distance ~ age + Sex + (1 | Subject), data = Orthodont, REML=FALSE)
dd3 <- dredge(fm3)

# Get top-most models, but fitted by REML:
(top.models.3 <- get.models(dd3, subset = delta < 4, REML=TRUE))
# use: method = "REML" for older versions of lme4





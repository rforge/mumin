### Encoding: utf-8

### Name: get.models
### Title: Get models
### Aliases: get.models
### Keywords: models

### ** Examples

# Mixed models:

require(nlme)
fm2 <- lme(distance ~ age + Sex, data = Orthodont, random = ~ 1 | Subject, method="ML")
dd2 <- dredge(fm2)

# Get top-most models, but fitted by REML:
(top.models.2 <- get.models(dd2, subset = delta < 4, method = "REML"))





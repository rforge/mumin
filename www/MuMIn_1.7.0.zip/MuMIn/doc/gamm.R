### R code from vignette source 'gamm.Rnw'
### Encoding: CP1250

###################################################
### code chunk number 1: gamm.Rnw:23-30
###################################################
suppressPackageStartupMessages(suppressWarnings({
library(gamm4)
library(mgcv)
library(MuMIn)
}))

set.seed(0)


###################################################
### code chunk number 2: gamm.Rnw:57-61
###################################################
gamm <-
    function(...)
    structure(c(mgcv::gamm(...), list(call=match.call(mgcv::gamm))),
	class=c("gamm", "list"))


###################################################
### code chunk number 3: gamm.Rnw:64-68
###################################################
gamm4 <-
    function(...)
    structure(c(gamm4::gamm4(...), list(call=match.call(gamm4::gamm4))),
	class=c("gamm", "list"))


###################################################
### code chunk number 4: gamm.Rnw:82-89
###################################################
logLik.gamm <-
    function (object, ...) logLik(object[[if(is.null(object$lme))
    "mer" else "lme"]], ...)
formula.gamm <-
    function (x, ...) formula(x$gam, ...)
nobs.gamm <-
    function (object, ...)  nobs(object$gam, ...)


###################################################
### code chunk number 5: gamm.Rnw:100-107
###################################################

dat <- gamSim(6,n=100,scale=.2,dist="normal")
fm1 <- gamm(y~x0+x1+x2+x3,data=dat,random=list(fac=~1), method="ML")
fm2 <- lme(y~x0+x1+x2+x3,data=dat,random=list(fac=~1), method="ML")

logLik(fm1$lme)
logLik(fm2)


###################################################
### code chunk number 6: gamm.Rnw:111-117
###################################################
dat <- gamSim(6,n=100,scale=.2,dist="poisson")
fmg1 <- gamm4(y ~ x0+x1+x2+x3, family=poisson, data=dat,random=~ (1|fac))
fmg2 <- lmer(y ~ x0+x1 + x2 + x3 + (1|fac), family=poisson, data=dat)

logLik(fmg1$mer)
logLik(fmg2)


###################################################
### code chunk number 7: gamm.Rnw:124-131
###################################################

fmgs1 <- gamm4(y ~ x0+ s(x1, k=3, fx=TRUE)+ x2+ x3, family=poisson, data=dat,
	random=~ (1|fac))
fmgs2 <- lmer(y ~ x0+ x1 + I(x1^2) + x2+ x3 + (1|fac), family=poisson, data=dat)
logLik(fmgs1$mer)
logLik(fmgs2)



###################################################
### code chunk number 8: gamm.Rnw:139-140
###################################################
nobs.gam <- function (object, ...)  stats:::nobs.glm(object, ...)


###################################################
### code chunk number 9: gamm.Rnw:144-147
###################################################
coeffs.gamm <- function (model) coef(model$gam)
getAllTerms.gamm <- function (x, ...) getAllTerms(x$gam, ...)
coefTable.gamm <- function (model, ...) coefTable(model$gam, ...)


###################################################
### code chunk number 10: gamm.Rnw:156-162
###################################################

set.seed(0)
dat <- gamSim(6, n=100, scale=5, dist="normal")

fmgs2 <- gamm(y ~1+ s(x0)+ s(x3) + s(x2), family=gaussian, data=dat,
	random = list(fac=~1))


###################################################
### code chunk number 11: gamm.Rnw:166-167
###################################################
head(dd2 <- dredge(fmgs2))


###################################################
### code chunk number 12: gamm.Rnw:171-174
###################################################

summary(model.avg(dd2, subset= cumsum(weight) <= .95))




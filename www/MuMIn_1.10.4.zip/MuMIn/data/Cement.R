`Cement` <-
structure(list( X1 = c(7L, 1L, 11L, 11L, 7L, 11L, 3L, 1L, 2L, 21L, 1L,
11L, 10L), X2 = c(26L, 29L, 56L, 31L, 52L, 55L, 71L, 31L, 54L, 47L, 40L, 66L,
68L), X3 = c(6L, 15L, 8L, 8L, 6L, 9L, 17L, 22L, 18L, 4L, 23L, 9L, 8L), X4 =
c(60L, 52L, 20L, 47L, 33L, 22L, 6L, 44L, 22L, 26L, 34L, 12L, 12L), y = c(78.5,
74.3, 104.3, 87.6, 95.9, 109.2, 102.7, 72.5, 93.1, 115.9, 83.8, 113.3, 109.4)),
.Names = c("X1", "X2", "X3", "X4", "y"), class = "data.frame", row.names =
c(NA, -13L))

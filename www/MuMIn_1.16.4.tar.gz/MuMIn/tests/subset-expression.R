# Testing 'subset' expressions with local and global variables

q("no")


library(MuMIn)
options(na.action = "na.fail")

## `dredge`

fm1 <- lm(y ~ ., data = Cement)
dd1 <- dredge(fm1)

#environment(dredge) <- asNamespace("MuMIn")
#environment(get.models) <- asNamespace("MuMIn")
#environment(subset.model.selection) <- asNamespace("MuMIn")

# using global and local function:
Test2 <- function() runif(1) < .5

dd <-
(function() {
	Test1 <- function() TRUE
	dredge(fm1, subset = {X4} & dc(X4, X1) & Test1() & Test2())
})()


(function() {
x <- 1.5
test <- function(x, y) x < 1.5
subset(dd1, .[, 1] > 100 & has(X1) & test(X1))
})()


MuMIn:::subset_rework

environment(test) <- 
environment(exprApply) <- 
environment(.exprapply) <- 
environment(exprapply0) <- asNamespace("MuMIn")

expr <- quote(I(X2)[X3 > 5] & X4(X3) & has(X4) & dc(X4, X1) & Test1() & Test2())
subset_rework(expr, dd)

df <- dd1
ss <- subset_rework(quote(.[, 1L] < 100 & (df < 3 | has(X2, !X1))), df)
df[eval(ss), ]

ss <- subset_rework(quote((.[, 1L] > 100) & has(X1)), df)

environment(subset_rework) <-
environment(subset.model.selection) <-
asNamespace("MuMIn")

options(debug.print = T)


subset_rework(quote( dc(X1, X2)  &  (.[[ 1L]] < 100) &  has(X1)), df)


ss <- MuMIn:::subset_rework(quote((.[[ 1L]] < 100) &  has(X1)), df)
eval(ss)

subset(df, (.[[ 1L]] < 100) & X2 > .5 &  has(X2))

traceback()

test <- function(x, subset) {
	eval.parent(subset_rework(substitute(subset), x, substitute(x)))
}

test(df, (.[, 1L] > 100) & has(X1))

traceback()

exprApply(expr, "dc", .sub_dc_has, "z")

quote

asChar <- MuMIn:::asChar

object <- dd
expr <- quote(X4 & dc(X4, X1) & Test1() & Test2())
expr <- exprApply(expr, names(object), symbols = TRUE,
function(x, v, fun, objectname) {
	#print(match.call(expand.dots = TRUE))
	if(is.call(parent) && any(parent[[1L]] == c("I", "$", "@")))
		return(x)
	if(length(x) == 1L) return(call(fun, objectname, match(asChar(x), v)))
	x
}, v = names(object), fun = "[[", objectname = quote(Mana))
expr




expr

test <- function() exprapply0

test()

fixInNamespace(exprapply0, "MuMIn")

traceback()

## `subset.model.selection`

T2 <- TRUE
(function() {
	Test1 <- function() TRUE
	T1 <- FALSE
	subset(dd, (.[, 'X2'] > 0) & dc(X4, X3, X2, X1) & T2 & !T1 & Test1())
})()

#######
environment(subset_rework) <- asNamespace("MuMIn")
environment(exprApply) <- asNamespace("MuMIn")
environment(.exprapply) <- asNamespace("MuMIn")
#######



exprApply2 <- exprApply

X3 <- list(X1 = 1)
X1 <- 1
test <- identity
expr <- quote(test(X4 + X2) + I(X1)[] + I(X1)[1] + X3$X1 + dc(X1, X2))

eval(subset_rework(expr, dd))

dd




subsetmodify_toelements <-
function(subset, object, name) {
	rval <- exprApply(subset, names(object), symbols = TRUE,
		function(x, v, fun, dfname, parent) {
			if(is.call(parent) && any(parent[[1L]] == c("I", "$", "@")))
				return(x)
			if(length(x) == 1L) return(call(fun, as.name(dfname), match(asChar(x), v)))
			x
		}, v = names(object), fun = "[[", dfname = name)
	rval <- exprApply(rval, "I", symbols = FALSE, function(x, parent) x[[2L]])
	rval
}

subsetmodify_toelements(expr, dd, "dd")


subst_tovectorelements <-
function(expr, object, name) {
	rval <- exprApply(subset, names(object), symbols = TRUE,
		function(x, v, fun, dfname, parent) {
			if(is.call(parent) && any(parent[[1L]] == c("I", "$", "@")))
				return(x)
			if(length(x) == 1L) return(call(fun, as.name(dfname), match(asChar(x), v)))
			x
		}, v = names(object), fun = "[", dfname = name)
	rval <- exprApply(rval, "I", symbols = FALSE, function(x, parent) x[[2L]])
	rval
}



traceback()

.subst4Vec(quote(X1 + X2 + X1[X2] + X3(X4)), c("X1", "X2", "X3", "X4"), "Z")



	eval(call("substitute", expr,
		env = structure(lapply(seq_len(n), function(i) call(fun, varName, i)),
						names = names)),
		envir = NULL)





object <- dd

exprApply(expr, "I", symbols = FALSE, function(x, parent) x[[2L]])

exprApply(expr, names(object), symbols = TRUE,
	function(x, parent) print(x))



# Enclosing in 'I' prevents a name from being interpreted as column name.

attr(.sub_dc_has, "what") <- "dc"
attr(.sub_Term, "what") <- c("{", "Term")
attr(.sub_has, "what") <- "has"

X1<- dd

(function(object, subset) {
	subset <- substitute(subset)
	print(subset)
	subset <- subsetmodify_toelements(subset, object, asChar(substitute(object)))
	expandSubsetExpr(subset, substitute(object))
})(X1, has(X4) & dc(X1, X4) | .[,1])


subsetmodify_toelements(x, dd, "dd")


## `get.models`

T2 <- TRUE
(function() {
	Test1 <- function() TRUE
	T1 <- FALSE
	length(get.models(dd, dc(X4, X3, X2, X1) & T2 & !T1 & Test1()))
})()

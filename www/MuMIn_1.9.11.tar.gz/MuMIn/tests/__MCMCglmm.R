if(length(find.package("MCMCglmm", quiet = TRUE))) {

library(MCMCglmm)
library(MuMIn)
data("BTdata")
data("BTped")

## unfortunately MCMCglmm object does not include 'call' component, so it is
## impossible to update the object. This is a wrapper function to
## fix it:
uMCMCglmm <- updateable(MCMCglmm)
# or, a transparent version:
# MCMCglmm <- updateable(MCMCglmm::MCMCglmm)

prior <- list(R = list(V = diag(2)/3, n = 2),
	G = list(G1 = list(V = diag(2)/3, n = 2),
	G2 = list(V = diag(2)/3, n = 2)))


# the model runs very long, so I use parallel version:
require(parallel)
# Set up the cluster
clust <- makeCluster(4, type = "PSOCK")
clusterEvalQ(clust, library(MCMCglmm))
clusterExport(clust, c("uMCMCglmm", "prior", "BTped", "BTdata"))
##


m1 <- uMCMCglmm(cbind(tarsus, back) ~ trait:sex + trait:hatchdate - 1,
	random = ~ us(trait):animal + us(trait):fosternest, rcov = ~ us(trait):units,
	prior = prior, family = rep("gaussian", 2), thin = 25, data = BTdata, pedigree = BTped)

# checking if it is possible now to retrieve the original call:
getCall(m1)

# 'dredge' does not manipulate random terms, so adding them as 'fixed' is not necessary.

## checking if the generated calls are what we want:
pdredge(m1, clust = clust, rank = DIC, m.min = 1, evaluate = FALSE, check = FALSE)

dd <- pdredge(m1, clust = clust, rank = DIC)

# there are some warnings during fitting, to get rid of them:
attr(dd, "warnings") <- NULL

#mod <- pget.models(dd, cluster = clust)
#model.sel(mod, rank = DIC)

}
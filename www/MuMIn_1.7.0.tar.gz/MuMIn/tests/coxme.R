library(coxme)
library(MuMIn)


#temp <- with(lung, scale(cbind(age, wt.loss, meal.cal)))
rfit0 <- coxme(Surv(time, status) ~ ph.ecog + ph.karno + (age | 1) + (wt.loss | 1), data=lung)

dredge(rfit0, eval = F)

dd <- dredge(rfit0, eval = T, trace = T)

model.sel(dd, rank = AIC)

summary(model.avg(dd))


pkgname <- "MuMIn"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
options(pager = "console")
library('MuMIn')

assign(".oldSearch", search(), pos = 'CheckExEnv')
cleanEx()
nameEx("AICc")
### * AICc

flush(stderr()); flush(stdout())

### Name: AICc
### Title: Second-order Akaike Information Criterion
### Aliases: AICc
### Keywords: models

### ** Examples


#Model-averaging mixed models

library(nlme)
data(Orthodont, package = "nlme")

# Fit model by REML
fm2 <- lme(distance ~ Sex*age, data = Orthodont,
    random = ~ 1|Subject / Sex, method = "REML")

# Model selection: ranking by AICc using ML
ms2 <- dredge(fm2, trace = TRUE, rank = "AICc", REML = FALSE)

(attr(ms2, "rank.call"))

# Get the models (fitted by REML, as in the global model)
fmList <- get.models(ms2, 1:4)

# Because the models originate from 'dredge(..., rank=AICc, REML=FALSE)',
# the default weights in 'model.avg' are ML based:
summary(model.avg(fmList))

# same result
#model.avg(fmList, rank = "AICc", rank.args = list(REML=FALSE))




cleanEx()
nameEx("MuMIn-package")
### * MuMIn-package

flush(stderr()); flush(stdout())

### Name: MuMIn-package
### Title: Multi-model inference
### Aliases: MuMIn-package MuMIn
### Keywords: package models

### ** Examples


data(Cement)

fm1 <- lm(y ~ ., data = Cement)

ms1 <- dredge(fm1)
confset.d4 <- get.models(ms1, subset = delta < 4)
model.avg(confset.d4)

confset.95p <- get.models(ms1, cumsum(weight) <= .95)
avgmod.95p <- model.avg(confset.95p)
summary(avgmod.95p)
confint(avgmod.95p)




cleanEx()
nameEx("QAIC")
### * QAIC

flush(stderr()); flush(stdout())

### Name: QAIC
### Title: Quasi AIC or AICc
### Aliases: QAIC QAICc
### Keywords: models

### ** Examples

# Based on "example(predict.glm)", with one number changed to create
# overdispersion
budworm <- data.frame(
    ldose = rep(0:5, 2), sex = factor(rep(c("M", "F"), c(6, 6))),
    numdead = c(10, 4, 9, 12, 18, 20, 0, 2, 6, 10, 12, 16))
budworm$SF = cbind(numdead = budworm$numdead,
    numalive = 20 - budworm$numdead)

budworm.lg <- glm(SF ~ sex*ldose, data = budworm, family = binomial)
(chat <- deviance(budworm.lg) / df.residual(budworm.lg))

dredge(budworm.lg, rank = "QAIC", chat = chat)
dredge(budworm.lg, rank = "AIC")

## Not run: 
##D # Ugly hacked constructor for quasibinomial family object, that allows for
##D # ML estimation
##D x.quasibinomial <- function(...) {
##D     res <- quasibinomial(...)
##D     res$aic <- binomial(...)$aic
##D     res
##D }
##D QAIC(update(budworm.lg, family = x.quasibinomial), chat = chat)
## End(Not run)



cleanEx()
nameEx("beetle")
### * beetle

flush(stderr()); flush(stdout())

### Name: Beetle
### Title: Flour beetle mortality data
### Aliases: Beetle
### Keywords: datasets

### ** Examples


# "Logistic regression example"
# from Burnham & Anderson (2002) chapter 4.11

data(Beetle)

# Fit a global model with all the considered variables
globmod <- glm(Prop ~ dose + I(dose^2) + log(dose) + I(log(dose)^2),
    data = Beetle, family = binomial)


# A logical expression defining the subset of models to use:
# * either log(dose) or dose
# * the quadratic terms can appear only together with linear terms
msubset <- expression(xor(dose, `log(dose)`) & (dose | !`I(dose^2)`)
    & (`log(dose)` | !`I(log(dose)^2)`))


# Table 4.6

# Use 'varying' argument to fit models with different link functions
# Note the use of 'alist' rather than 'list' in order to keep the
# 'family' objects unevaluated
varying.link <- list(family = alist(
    logit = binomial("logit"),
    probit = binomial("probit"),
    cloglog = binomial("cloglog")
    ))

(ms12 <- dredge(globmod, subset = msubset, varying = varying.link,
    rank = AIC))

##### traceback()

# Table 4.7 "models justifiable a priori"
(ms3 <- subset(ms12, has(dose, !`I(dose^2)`)))
# The same result, but would fit the models again:
# ms3 <- update(ms12, update(globmod, . ~ dose), subset =,
#    fixed = ~dose)

mod3 <- get.models(ms3, 1:3)

# Table 4.8. Predicted mortality probability at dose 40.

# calculate confidence intervals on logit scale
logit.ci <- function(p, se, quantile = 2) {
    C. <- exp(quantile * se / (p * (1 - p)))
    p /(p + (1 - p) * c(C., 1/C.))
}

pred <- sapply(mod3, predict, newdata = list(dose = 40), se.fit = TRUE,
    type = "response")
pred <- apply(pred, 1, unlist)[, 1:2] # simplify

# build the table
tab <- rbind(pred, par.avg(pred[, "fit"], pred[, "se.fit"], Weights(ms3),
    revised.var = FALSE)[1:2])
tab <- cbind(
    c(Weights(ms3), NA),
    tab,
    matrix(logit.ci(tab[,"fit"], tab[,"se.fit"],
        quantile = c(rep(1.96, 3), 2)), ncol = 2)
    )
colnames(tab) <- c("Akaike weight", "Predicted(40)", "SE", "Lower CI",
    "Upper CI")
rownames(tab) <- c(as.character(ms3$family), "model averaged")

print(tab, digits = 3, na.print = "")


# Figure 4.3
newdata <- list(dose = seq(min(Beetle$dose), max(Beetle$dose),
    length.out = 25))
matplot(newdata$dose, sapply(mod3, predict, newdata, type="response"),
    type = "l", xlab = quote(list("Dose of" ~ CS[2],(mg/L))),
    ylab = "Mortality", col = 2:4, lty = 3, lwd = 1
)

# add model-averaged prediction with CI, using the same method as above
pred <- lapply(mod3, predict, newdata, type = "response", se.fit = TRUE)
pred.y <- sapply(pred, "[[", "fit")
pred.se <- sapply(pred, "[[", "se.fit")
avpred <- sapply(1:25, function(i) par.avg(pred.y[i, ], pred.se[i, ],
    weight = Weights(ms3), revised.var = FALSE)[1:2])
avci <- matrix(logit.ci(avpred[1, ], avpred[2, ], quantile = 2),
    ncol = 2)
matplot(newdata$dose, cbind(avpred[1, ], avci), type = "l", add = TRUE,
    lwd = 1, lty = c(1, 2, 2), col = 1)
legend("topleft", NULL, c(as.character(ms3$family), expression(`averaged`
    %+-% CI)), lty = c(3, 3, 3, 1), col = c(2:4, 1))




cleanEx()
nameEx("dredge")
### * dredge

flush(stderr()); flush(stdout())

### Name: dredge
### Title: Automated model selection
### Aliases: dredge print.model.selection
### Keywords: models

### ** Examples

# Example from Burnham and Anderson (2002), page 100:
data(Cement)
fm1 <- lm(y ~ ., data = Cement)
dd <- dredge(fm1)
subset(dd, delta < 4)

# Visualize the model selection table:
if(require(graphics))
plot(dd)


# Model average models with delta AICc < 4
model.avg(dd, subset = delta < 4)

#or as a 95% confidence set:
model.avg(dd, subset = cumsum(weight) <= .95) # get averaged coefficients

#'Best' model
summary(get.models(dd, 1))[[1]]

## Not run: 
##D # Examples of using 'subset':
##D # exclude models containing both X1 and X2
##D dredge(fm1, subset = !(X1 & X2))
##D # keep only models containing X3
##D dredge(fm1, subset = ~ X3) # subset as a formula
##D dredge(fm1, subset = expression(X3)) # subset as expression object
##D # the same, but more effective:
##D dredge(fm1, fixed = "X3")
##D 
##D #Reduce the number of generated models, by including only those with
##D # up to 2 terms (and intercept)
##D dredge(fm1, m.max = 2)
## End(Not run)


# Add R^2 and F-statistics, use the 'extra' argument
dredge(fm1, m.max = 1, extra = c("R^2", F = function(x)
    summary(x)$fstatistic[[1]]))

# with summary statistics:
dredge(fm1, m.max = 1, extra = list(
    "R^2", "*" = function(x) {
        s <- summary(x)
        c(Rsq = s$r.squared, adjRsq = s$adj.r.squared,
            F = s$fstatistic[[1]])
    })
)


# with other information criterions:

# there is no BIC in R < 2.13.0, so need to add it:
if(!exists("BIC", mode = "function"))
    BIC <- function(object, ...)
        AIC(object, k = log(length(resid(object))))

dredge(fm1, m.max = 1, extra = alist(AIC, BIC, ICOMP, Cp))





cleanEx()
nameEx("get.models")
### * get.models

flush(stderr()); flush(stdout())

### Name: get.models
### Title: Get models
### Aliases: get.models pget.models
### Keywords: models

### ** Examples

# Mixed models:

require(nlme)
fm2 <- lme(distance ~ age + Sex, data = Orthodont,
    random = ~ 1 | Subject, method = "ML")
ms2 <- dredge(fm2)

# Get top-most models, but fitted by REML:
(confset.d4 <- get.models(ms2, subset = delta < 4, method = "REML"))




cleanEx()
nameEx("importance")
### * importance

flush(stderr()); flush(stdout())

### Name: importance
### Title: Relative variable importance
### Aliases: importance
### Keywords: models

### ** Examples


# Generate some models
data(Cement)
fm1 <- lm(y ~ ., data = Cement)
ms1 <- dredge(fm1)

# Importance can be calculated/extracted from various objects:
importance(ms1)
## Not run: 
##D importance(subset(mod.sel(ms1), delta <= 4))
##D importance(model.avg(ms1, subset = delta <= 4))
##D importance(subset(ms1, delta <= 4))
##D importance(get.models(ms1, delta <= 4))
## End(Not run)

# Re-evaluate the importances according to BIC
# note that re-ranking involves fitting the models again

# 'nobs' is not used here for backwards compatibility
lognobs <- log(length(resid(fm1)))

importance(subset(mod.sel(ms1, rank = AIC, rank.args = list(k = lognobs)),
	cumsum(weight) <= .95))

# This gives a different result than previous command, because 'subset' is
# applied to the original selection table that is ranked with 'AICc'
importance(model.avg(ms1, rank = AIC, rank.args = list(k = lognobs),
	subset = cumsum(weight) <= .95))




cleanEx()
nameEx("mod.sel")
### * mod.sel

flush(stderr()); flush(stdout())

### Name: model.sel
### Title: model selection table
### Aliases: mod.sel model.sel model.sel.default model.sel.model.selection
###   model.sel
### Keywords: models

### ** Examples


data(Cement)
Cement$X1 <- cut(Cement$X1, 3)
Cement$X2 <- cut(Cement$X2, 2)

fm1 <- glm(formula = y ~ X1 + X2 * X3, data = Cement)
fm2 <- update(fm1, . ~ . - X1 - X2)
fm3 <- update(fm1, . ~ . - X2 - X3)

## ranked with AICc by default
(msAICc <- model.sel(fm1, fm2, fm3))

## ranked with BIC
model.sel(fm1, fm2, fm3, rank = AIC, rank.args = alist(k = log(nobs(x))))
# or
# model.sel(msAICc, rank = AIC, rank.args = alist(k = log(nobs(x))))
# or
# update(msAICc, rank = AIC, rank.args = alist(k = log(nobs(x))))





cleanEx()
nameEx("model.avg")
### * model.avg

flush(stderr()); flush(stdout())

### Name: model.avg
### Title: Model averaging
### Aliases: model.avg model.avg.default model.avg.model.selection
###   print.averaging
### Keywords: models

### ** Examples


# Example from Burnham and Anderson (2002), page 100:
library(MuMIn)
data(Cement)
fm1 <- lm(y ~ ., data = Cement)
(ms1 <- dredge(fm1))

#models with delta.aicc < 4
summary(model.avg(ms1, subset = delta < 4))

#or as a 95% confidence set:
avgmod.95p <- model.avg(ms1, cumsum(weight) <= .95)
confint(avgmod.95p)

## Not run: 
##D # The same result, but re-fitting the models via 'get.models'
##D confset.95p <- get.models(ms1, cumsum(weight) <= .95)
##D model.avg(confset.95p)
##D 
##D # Force re-fitting the component models
##D model.avg(ms1, cumsum(weight) <= .95, fit = TRUE)
##D # Models are also fitted if additional arguments are given
##D model.avg(ms1, cumsum(weight) <= .95, rank = "AIC")
## End(Not run)

## Not run: 
##D # using BIC (Schwarz's Bayesian criterion) to rank the models
##D BIC <- function(x) AIC(x, k = log(length(residuals(x))))
##D model.avg(confset.95p, rank = BIC)
##D # the same result, using AIC directly, with argument k
##D # 'x' in a quoted 'rank' argument is substituted with a model object
##D # (in this case it does not make much sense as the number of observations is
##D # common to all models)
##D model.avg(confset.95p, rank = AIC, rank.args = alist(k = log(length(residuals(x)))))
## End(Not run)




cleanEx()
nameEx("pdredge")
### * pdredge

flush(stderr()); flush(stdout())

### Name: pdredge
### Title: Automated model selection using parallel computation
### Aliases: pdredge
### Keywords: models

### ** Examples


## Don't show: 
# Normally this should be simply "require(parallel) || require(snow)",
# but here we resort to an (ugly) trick to avoid MuMIn's dependency on one of
# these packages and still pass R-check (it is just temporary solution, while
# 'pdredge' as well as the 'parallel' package are in experimental stage):
if(MuMIn:::.parallelPkgCheck(quiet = TRUE)) {
## End Don't show

# One of these packages is required:
## Not run: require(parallel) || require(snow)

# From example(Beetle)
data(Beetle)

Beetle100 <- Beetle[sample(nrow(Beetle), 100, replace = TRUE),]

fm1 <- glm(Prop ~ dose + I(dose^2) + log(dose) + I(log(dose)^2),
    data = Beetle100, family = binomial)

msubset <- expression(xor(dose, `log(dose)`) & (dose | !`I(dose^2)`)
    & (`log(dose)` | !`I(log(dose)^2)`))
varying.link <- list(family = alist(logit = binomial("logit"),
    probit = binomial("probit"), cloglog = binomial("cloglog") ))

# Set up the cluster
clusterType <- if(length(.find.package("snow", quiet = TRUE))) "SOCK" else "PSOCK"
clust <- try(makeCluster(getOption("cl.cores", 2), type = clusterType))
## Don't show: 
if(inherits(clust, "cluster")) { 
## End Don't show
clusterExport(clust, "Beetle100")

# noticeable gain only when data has about 3000 rows (Windows 2-core machine)
print(system.time(dredge(fm1, subset = msubset, varying = varying.link)))
print(system.time(pdredge(fm1, cluster = FALSE, subset = msubset,
    varying = varying.link)))
print(system.time(pdredge(fm1, cluster = clust, subset = msubset,
    varying = varying.link)))

## Not run: 
##D # A time consuming example with 'unmarked' model, based on example(pcount).
##D # Having enough patience, you can run this with 'demo(pdredge.pcount)'.
##D library(unmarked)
##D data(mallard)
##D mallardUMF <- unmarkedFramePCount(mallard.y, siteCovs = mallard.site,
##D     obsCovs = mallard.obs)
##D (ufm.mallard <- pcount(~ ivel + date + I(date^2) ~ length + elev + forest,
##D     mallardUMF, K = 30))
##D clusterEvalQ(clust, library(unmarked))
##D clusterExport(clust, "mallardUMF")
##D 
##D # 'stats4' is needed for AIC to work with unmarkedFit objects but is not
##D # loaded automatically with 'unmarked'.
##D require(stats4)
##D invisible(clusterCall(clust, "library", "stats4", character.only = TRUE))
##D 
##D #system.time(print(pdd1 <- pdredge(ufm.mallard,
##D #   subset = `p(date)` | !`p(I(date^2))`, rank = AIC)))
##D 
##D system.time(print(pdd2 <- pdredge(ufm.mallard, clust,
##D     subset = `p(date)` | !`p(I(date^2))`, rank = AIC, extra = "adjR^2")))
##D 
##D 
##D # best models and null model
##D subset(pdd2, delta < 2 | df == min(df))
##D 
##D # Compare with the model selection table from unmarked
##D # the statistics should be identical:
##D models <- pget.models(pdd2, clust, delta < 2 | df == min(df))
##D 
##D modSel(fitList(fits = structure(models, names = model.names(models,
##D     labels = getAllTerms(ufm.mallard)))), nullmod = "(Null)")
## End(Not run)

stopCluster(clust)
## Don't show: 
 
} else # if(! inherits(clust, "cluster"))
message("Could not set up the cluster")
} 
## End Don't show




cleanEx()
nameEx("predict.averaging")
### * predict.averaging

flush(stderr()); flush(stdout())

### Name: predict.averaging
### Title: Predict method for the averaged model
### Aliases: predict.averaging
### Keywords: models

### ** Examples


require(graphics)

# Example from Burnham and Anderson (2002), page 100:
data(Cement)
fm1 <- lm(y ~ X1 + X2 + X3 + X4, data = Cement)

ms1 <- dredge(fm1)
confset.95p <- get.models(ms1, subset = cumsum(weight) <= .95)
avgm <- model.avg(confset.95p)

nseq <- function(x, len = length(x)) seq(min(x, na.rm = TRUE),
    max(x, na.rm=TRUE), length = len)

# New predictors: X1 along the range of original data, other
# variables held constant at their means
newdata <- as.data.frame(lapply(lapply(Cement[1:4], mean), rep, 25))
newdata$X1 <- nseq(Cement$X1, nrow(newdata))

n <- length(confset.95p)

# Predictions from each of the models in a set, and with averaged coefficients
pred <- data.frame(
	model = sapply(confset.95p, predict, newdata = newdata),
	averaged.subset = predict(avgm, newdata, full = FALSE),
    averaged.full = predict(avgm, newdata, full = TRUE)
	)

opal <- palette(c(topo.colors(n), "black", "red", "orange"))
matplot(newdata$X1, pred, type = "l",
	lwd = c(rep(2,n),3,3), lty = 1,
    xlab = "X1", ylab = "y", col=1:7)

# For comparison, prediction obtained by averaging predictions of the component
# models
pred.se <- predict(avgm, newdata, se.fit = TRUE)
y <- pred.se$fit
ci <- pred.se$se.fit  * 2
matplot(newdata$X1, cbind(y, y - ci, y + ci), add = TRUE, type="l",
	lty = 2, col = n + 3, lwd = 3)

legend("topleft",
    legend=c(lapply(confset.95p, formula),
        paste(c("subset", "full"), "averaged"), "averaged predictions + CI"),
    lty = 1, lwd = c(rep(2,n),3,3,3),  cex = .75, col=1:8)

palette(opal)




cleanEx()
nameEx("subset.model.selection")
### * subset.model.selection

flush(stderr()); flush(stdout())

### Name: subset.model.selection
### Title: Subsetting model selection table
### Aliases: subset.model.selection [.model.selection has
### Keywords: manip

### ** Examples

data(Cement)
fm1 <- lm(formula = y ~ X1 + X2 + X3 + X4, data = Cement)

# generate models where each variable is included only if the previous
# are included too, e.g. X2 only if X1 is there, and X3 only if X2 and X1
dredge(fm1, subset = (!X2 | X1) & (!X3 | X2) & (!X4 | X3))

# alternatively, generate "all possible" combinations
ms0 <- dredge(fm1)
# ...and afterwards select the subset of models
subset(ms0, (has(!X2) | has(X1)) & (has(!X3) | has(X2)) & (has(!X4) | has(X3)))
## Not run: 
##D # this way the expression may be more clear
##D subset(ms0, has(X1, X2, X3, X4) | has(X1, X2, X3) | has(X1, X2) | has(X1)
##D     | (df == 2))
## End(Not run)

# Different ways of finding a confidence set of models:
# delta(AIC) cutoff
subset(ms0, delta <= 4, recalc.weights = FALSE)
# cumulative sum of Akaike weights
subset(ms0, cumsum(weight) <= .95, recalc.weights = FALSE)
# relative likelihood
subset(ms0, (weight / weight[1]) > (1/8), recalc.weights = FALSE)



cleanEx()
nameEx("weights")
### * weights

flush(stderr()); flush(stdout())

### Name: Weights
### Title: Akaike weights
### Aliases: Weights
### Keywords: models

### ** Examples


data(Beetle)

fm1 <- glm(Prop ~ dose, data=Beetle, family=binomial)
fm2 <- update(fm1, . ~ . + I(dose^2))
fm3 <- update(fm1, . ~ log(dose))
fm4 <- update(fm3, . ~ . + I(log(dose)^2))

round(Weights(AICc(fm1, fm2, fm3, fm4)), 3)





### * <FOOTER>
###
cat("Time elapsed: ", proc.time() - get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')

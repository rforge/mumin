library(MuMIn)
options(debug.print = TRUE)


testSubsetMatrixConformance <-
function(subset, ...) {
	cl <- match.call()
	cl[[1L]] <- as.name("dredge")
	print(cl)
	dd <- eval.parent(cl)
	if(!is.matrix(subset)) {
		message("subset is not a matrix")
		return(invisible())
	}
	if(!is.null(dimnames(subset))) {
		for(v1 in colnames(subset)) 
		for(v2 in rownames(subset)) {
			g <- subset[v2, v1]
			if(is.na(g)) next 
			x <- !is.na(dd[, c(v1, v2)])
			x <- x[, 1] & x[, 2]
			if(!g && any(x)) stop("'dredge' result does not conform subset[", v1,
				", ", v2, "] == FALSE")
		}
		message("'dredge' vs subset matrix is OK")
	} else {
		message("not checking unnamed subset matrix")
	}
}




n <- 350
v <- all.vars(TicksYN ~ AllVeg100 + Trees100 + GroundVeg100 + Imperv100 + WaterImperv100 + Humidity)
z <- matrix(ncol = length(v), nrow = n, dimnames = list(NULL, v))
z[, -1] <- runif(length(z[, -1]), -10, 10)
z[, 1] <- rbinom(n, prob = plogis(z[,-1] %*% c(1,1,1,1,1,1)), size = 1)
z <- as.data.frame(z)

fm <- glm(formula = TicksYN ~ AllVeg100 + Trees100 + GroundVeg100 +
    Imperv100 + WaterImperv100 + Humidity, family = "binomial",
    data = z, na.action = na.fail)

ss <- matrix(NA, 6,6, dimnames = list(v[-1], v[-1]))
ss[lower.tri(ss)] <- TRUE
ss[c(2,3,9,23)] <- FALSE

print(ss, na.print = "")

dd <- testSubsetMatrixConformance(fm, subset = ss)


library(RMark)
library(MuMIn)

##==============================================================================
options(width = 200)
#library(formatR)
#tidy.source("clipboard", replace.assign = T, width.cutoff = 80)

data(robust)

time.intervals <- c(0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0)

mod1 <- mark(data = robust, model = "RDHet",
	time.intervals = time.intervals, 
    model.parameters = list(
		S = list(formula = ~time),
		GammaDoublePrime = list(formula = ~time, share = TRUE), 
        p = list(formula = ~session * mixture, share = TRUE),
		pi = list(formula = ~1)
		),
	threads = 4L, invisible = T, silent = T, output = F)

dd <- dredge(mod1)

(dd)

summary(model.avg(dd))


rm(mod1)
cleanup(ask = FALSE)

##==============================================================================
## From example(dipper)
data(dipper)
# Process data
dip.proc <- process.data(dipper, groups = "sex")
# Create default design data
dip.ddl <- make.design.data(dip.proc)
# Add Flood covariates for Phi and p that have different values
dip.ddl$Phi$Flood <- 0
dip.ddl$Phi$Flood[dip.ddl$Phi$time == 2 | dip.ddl$Phi$time == 3] <- 1
dip.ddl$p$Flood <- 0
dip.ddl$p$Flood[dip.ddl$p$time == 3] <- 1


dip1 <- make.mark.model(dip.proc, dip.ddl, parameters =
	list(
		 Phi = list(formula = ~ time * Flood),
		 p = list(formula = ~sex * time))
)

dipr1 <- run.mark.model(dip1, invisible = T)
dd2 <- dredge(dipr1, trace = T, eval = T)

##==============================================================================


dip2 <- mark(dip.proc, ddl = dip.ddl, model.parameters =
	list(
		 Phi = list(formula = ~ time),
		 p = list(formula = ~sex * time)),
	threads = 4L, invisible = T, silent = T, output = F)

dd3 <- dredge(dip2)

summary(ma <- model.avg(dd3))

mod <- get.models(dd3[1:3])

summary(model.avg(dd3[1:3]))
summary(model.avg(mod))

##==============================================================================

rm(list = ls(all = TRUE))
cleanup(ask = FALSE)


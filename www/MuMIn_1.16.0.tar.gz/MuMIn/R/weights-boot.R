

bootWeights <- 
function(object, ...,
		 R,
		 rank = c("AICc", "AIC", "BIC"),
		 seed = NULL
		) {
	
	models <- getModelArgs()
	m <- length(models)

	if(m < 2) stop("need more than one model")

	.checkModels(models)
	
	for(fm in models) {
	  if(is.na(match("x", names(fm)))) {
		warning("for efficiency of the bootstrap procedure, 'glm' should be called with 'x = TRUE'")
		break
	  }
	}
	
	rank <- match.arg(rank)
	
	ic <- switch(rank, AICc = AICc, AIC = AIC, BIC = BIC)
	
	set.seed(seed)

	mseq <- seq.int(m)
	
	if(all(vapply(models, inherits, FALSE, "glm"))) { ## !force.update &&
	  	best <- integer(R)
		ics <- numeric(m)
		n <- nobs(models[[1L]]) # assuming nobs is the same across models
		r <- 1L
		while(r <= R) {
			g <- sample.int(n, replace = TRUE)

			for(j in mseq) {
				fit <- models[[j]]
				fit1 <- glm.fit(model.matrix(fit)[g, , drop = FALSE], fit$y[g], fit$prior.weights[g],
				  offset = fit$offset[g], family = fit$family)
				ics[j] <- ic(loglik_glm_fit(fit1))
			}
			best[r] <- which.min(ics)
			r <- r + 1L
		}
	} else stop("all model objects must be of \"glm\" class")
  
	wts <- tabulate(best, m)
	wts <- wts  / sum(wts)
	structure(wts, name = "bootstrap", class = c("model.weights", class(wts)))
}

loo <-
function(object, method = c("loglik", "rmse"), ...)
	UseMethod("loo")

loo.default <-
function(object, method = c("loglik", "rmse"), ...)
	.NotYetImplemented()
	# for other types of models use manipulated call - will be SLOW


loo.lm <- # lm, glm, mgcv::gam
function(object, method = c("loglik", "rmse"), start, etastart, mustart,
		 control, intercept, ...) {
	
	if(!inherits(object, "lm"))
		stop("'object' must be a \"glm\" or \"lm\" object")
	
	## TODO: pass other arguments: 
	if(!missing(start) || !missing(etastart)  || !missing(mustart)  ||
	   !missing(control) || !missing(intercept)) {
		warning("arguments 'start', 'etastart', 'mustart', 'control', 'intercept' are ignored")
	}
	## binary response: object$y is always a vector and weights(object) give size

	method <- match.arg(method)
	tt <- terms(object)
	intercept <- attr(tt, "intercept") # == 0 or 1
	beta <- coef(object)

	fam <- family(object)
	x <- model.matrix(object)
	if(inherits(object, "glm")) {
		y <- object$y
	} else {
		y <- model.frame(object)[, asChar(attr(tt, "variables")[-1L][[attr(tt, "response")]])]
		if(is.matrix(y)) y <- y[, 1L] / rowSums(y) # binomial
	}
	n <- length(y)

	wt <- weights(object, "prior")
	if(is.null(wt)) wt <- rep(1, n)
	
	offset <- object$offset
	if(is.null(offset)) offset <- numeric(n)
	
	dev <- deviance(object)
	aicfun <- fam$aic
	aic_n <- if(fam$family == "binomial") wt else rep(1, n)
	yt <- fam$linkfun(y)

	func <- switch(method,
		loglik = function(fit, i) {
			py1 <- predict_glm_fit(fit$coefficients, x[i, , drop = FALSE],
				offset[i], fam)[, 1L]
			aicfun(y[i], aic_n[i], py1, wt[i], deviance(fit)) / 2 # == logLik
		},
		rmse = function(fit, i) { # alternatively: MSE on transformed[?] data
			py1 <- predict_glm_fit(fit$coefficients, x[i, , drop = FALSE],
				offset[i])[, 1L]
				# prediction on link scale
			yt[i] - py1 # inefficient to '^2' here
		})

	rval <- numeric(n)
	for (i in seq.int(n)) {
		fm1 <- glm.fit(y = y[-i], x = x[-i, , drop = FALSE],
				family = fam, offset = offset[-i], weights = wt[-i])
		rval[i] <- func(fm1, i)
	}

	if(method == "rmse") {
		sqrt(mean(rval^2))
	} else mean(rval) # XXX: shoult it be a mean of logliks ?
}
